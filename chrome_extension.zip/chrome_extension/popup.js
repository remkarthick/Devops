document.addEventListener('DOMContentLoaded', () => {
    // Tabs
    const tabs = document.querySelectorAll('.tab-btn');
    const contents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            contents.forEach(c => c.classList.add('hidden'));

            tab.classList.add('active');
            const targetId = tab.getAttribute('data-tab');
            document.getElementById(targetId).classList.remove('hidden');
        });
    });

    // Body Type Toggle
    const bodyRadios = document.getElementsByName('body-type');
    const jsonBody = document.getElementById('json-body');

    bodyRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            if (e.target.value === 'json') {
                jsonBody.disabled = false;
                jsonBody.focus();
            } else {
                jsonBody.disabled = true;
            }
        });
    });

    // Dynamic Key-Value Rows
    const addRowBtns = document.querySelectorAll('.add-row-btn');

    addRowBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-target');
            const container = document.getElementById(targetId);
            const row = document.createElement('div');
            row.className = 'key-value-row';
            const keyClass = targetId === 'params-list' ? 'param-key' : 'header-key';
            const valueClass = targetId === 'params-list' ? 'param-value' : 'header-value';

            row.innerHTML = `
        <input type="text" placeholder="Key" class="${keyClass}">
        <input type="text" placeholder="Value" class="${valueClass}">
        <button class="remove-row" style="background:none;border:none;color:#ef4444;cursor:pointer;">&times;</button>
      `;
            container.appendChild(row);

            row.querySelector('.remove-row').addEventListener('click', () => {
                container.removeChild(row);
            });
        });
    });

    // Send Request
    const sendBtn = document.getElementById('send-btn');
    const responseSection = document.getElementById('response-section');
    const statusEl = document.getElementById('status');
    const timeEl = document.getElementById('time');
    const outputEl = document.getElementById('response-output');

    sendBtn.addEventListener('click', async () => {
        const method = document.getElementById('method').value;
        let url = document.getElementById('url').value.trim();

        if (!url) {
            alert('Please enter a URL');
            return;
        }

        // Process Params
        const paramKeys = document.querySelectorAll('.param-key');
        const paramValues = document.querySelectorAll('.param-value');
        const params = new URLSearchParams();

        paramKeys.forEach((keyEl, index) => {
            const key = keyEl.value.trim();
            const value = paramValues[index].value.trim();
            if (key) params.append(key, value);
        });

        if (params.toString()) {
            url += (url.includes('?') ? '&' : '?') + params.toString();
        }

        // Process Headers
        const headerKeys = document.querySelectorAll('.header-key');
        const headerValues = document.querySelectorAll('.header-value');
        const headers = {};

        headerKeys.forEach((keyEl, index) => {
            const key = keyEl.value.trim();
            const value = headerValues[index].value.trim();
            if (key) headers[key] = value;
        });

        // Process Body
        let body = null;
        const bodyType = document.querySelector('input[name="body-type"]:checked').value;

        if (['POST', 'PUT', 'PATCH'].includes(method) && bodyType === 'json') {
            const activeBody = jsonBody.value.trim();
            if (activeBody) {
                try {
                    // Validate JSON
                    JSON.parse(activeBody);
                    body = activeBody;
                    if (!headers['Content-Type']) {
                        headers['Content-Type'] = 'application/json';
                    }
                } catch (e) {
                    alert('Invalid JSON Body');
                    return;
                }
            }
        }

        // Execute
        statusEl.textContent = 'Loading...';
        timeEl.textContent = '';
        outputEl.textContent = '';
        responseSection.classList.remove('hidden');

        const startTime = performance.now();

        try {
            const response = await fetch(url, {
                method,
                headers,
                body
            });

            const endTime = performance.now();
            const duration = (endTime - startTime).toFixed(2);

            statusEl.textContent = `${response.status} ${response.statusText}`;
            timeEl.textContent = `${duration}ms`;

            // Colorize status
            if (response.status >= 200 && response.status < 300) statusEl.style.color = '#22c55e';
            else if (response.status >= 400) statusEl.style.color = '#ef4444';
            else statusEl.style.color = '#f59e0b';

            const contentType = response.headers.get('content-type');
            let responseData;

            if (contentType && contentType.includes('application/json')) {
                responseData = await response.json();
                outputEl.textContent = JSON.stringify(responseData, null, 2);
            } else {
                responseData = await response.text();
                outputEl.textContent = responseData;
            }

        } catch (error) {
            statusEl.textContent = 'Error';
            statusEl.style.color = '#ef4444';
            timeEl.textContent = '';
            outputEl.textContent = error.message;
        }
    });
});
